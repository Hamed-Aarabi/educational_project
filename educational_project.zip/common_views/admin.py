from django.contrib import admin
# from .models import *
#
#
# @admin.register(CommentBaseClass)
# class CourseComment_Admin(admin.ModelAdmin):
#     list_display = ('__str__',)
