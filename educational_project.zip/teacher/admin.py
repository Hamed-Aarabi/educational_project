from django.contrib import admin
from .models import *

admin.site.register(Teacher)
admin.site.register(SocialMedia)
admin.site.register(TeachRule)
admin.site.register(TeachRequest)
